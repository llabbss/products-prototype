//var $,jQuery;
(function($){	
	//*************************************//
	//*************菜单左右切换插件*************//
	//************************************//	
	$.fn.oTabMenus = function (options) {
		//定义要用的参数
		var opts = {
			oTabMenuList: '',
			oMenuBtnL:'',
			oMenuBtnR:'',
			Distance:1,  //间隔
			greypreClass:'',
			greynextClass:''
		};
		var opt = $.extend(opts, options);
		return this.each(function () {
			var _obj = $(this),
			 	aLi = $(opt.oTabMenuList).find("li"),
			 	aMenus = $(opt.oTabMenuList).find("li a"),
				disX=0,
				l=0;			

			function reset() {
				var ulWidth;
				for (var i = 0; i < aLi.length; i++) {
					ulWidth += aLi.eq(i).width() + opt.Distance;
					console.log(aLi.eq(i));
				}
				$(opt.oTabMenuList).css("width", ulWidth);
				
				if ($(opt.oTabMenuList).width() > _obj.width()) {
					$(opt.oMenuBtnR).addClass(opt.greynextClass);
				}
				disX = $(opt.oTabMenuList).width() - _obj.width();
				//console.log($(opt.oTabMenuList).width());
			}
			reset();
			function move(dis) {
				$(opt.oTabMenuList).animate({"left": dis}, 500);
			}
			$(opt.oMenuBtnR).click(function () {
				if (l >= -disX) {
					//l += -(aLi.width()+opt.Distance);
					l += -(_obj.width());
					move(l);			
				}
				if (l < 0) {
					$(opt.oMenuBtnL).addClass(opt.greypreClass);
					//oMenuBtnL.fadeIn();			
				}
				if (l < -disX) {
					$(opt.oMenuBtnR).removeClass(opt.greynextClass);
					//oMenuBtnR.fadeOut();
				}
			});
			$(opt.oMenuBtnL).click(function () {
				if (l < 0) {
					//l += aLi.width()+opt.Distance;
					l += _obj.width();
					move(l);			
				}
				if (l >= 0) {
					$(opt.oMenuBtnL).removeClass(opt.greypreClass);
					//oMenuBtnL.fadeOut();
				}
				if (l >= -disX) {
					$(opt.oMenuBtnR).addClass(opt.greynextClass);
					//oMenuBtnR.fadeIn();
				}
			});
		});
		return this;
	};
	
//all end
})(jQuery);

//Document Ready
$(function() {
	//可以向两边滑动的选项卡菜单
	$('.tabroll').oTabMenus({oTabMenuList: '.nav_menu',oMenuBtnL:'.pre',oMenuBtnR:'.next',Distance:1,greypreClass:'cur_pre',greynextClass:'cur_next'});
	$('.lmenuroll').oTabMenus({oTabMenuList: '.lmenu',oMenuBtnL:'.lmenu_pre',oMenuBtnR:'.lmenu_next',Distance:6,greypreClass:'cur_pre',greynextClass:'cur_next'});	
});


