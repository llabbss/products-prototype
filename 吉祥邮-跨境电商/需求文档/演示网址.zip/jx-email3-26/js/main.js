// JavaScript Document
$(function(){
	showSelectBox();
	showSelectBox2();
	selectOn();
	controlSidenav();
	controlMailwidth();
	showMark();
	hideMark();
	bodyClick();

	//去掉input框的点击事件
	$("[data-unbind]").find("a").each(function(){
		$(this).unbind( "click" );
	});

	//可以向两边滑动的选项卡菜单
	//$('.tabroll').oTabMenus({oTabMenuList: '.nav_menu',oMenuBtnL:'.pre',oMenuBtnR:'.next',Distance:1,greypreClass:'cur_pre',greynextClass:'cur_next'});
	$('.lmenuroll').oTabMenus({oTabMenuList: '.lmenu',oMenuBtnL:'.lmenu_pre',oMenuBtnR:'.lmenu_next',Distance:6,greypreClass:'cur_pre',greynextClass:'cur_next'});	

	//
	if($('.lmenuroll').find("li").length>4){
		$('.lmenu_next').addClass('cur_next');
	}

});
//点击展开左侧菜单
function controlSidenav(){
	var btnsidenav=$("a[data-btnsidenav]");
	btnsidenav.click(function(){
		$(this).css({
			"right":"-30px",
			"background-position-y": "-61px",
		});
		if($(this).next().hasClass("btn-show")){
			$(this).next().removeClass("btn-show");
			$(this).parent().css({
			"width":"0px",
			});
			$(this).css({
				"background-position-y": "0",
			});
			$(".g-content").css("bottom","-130px");
		}else{
			$(this).next().addClass("btn-show");
			$(this).parent().css({
			"width":"201px",
			});
			$(".g-content").css("bottom","0");
		}
		
	});
}
//展开侧边菜单下拉框
function showSelectBox(){
	var aTxt =$("a[data-select]");
	aTxt.each(function(){
		var selectCon=$(this).next();
        	           $(this).click(function(){
        	           	selectCon.toggle();
        	           	if($(this).hasClass("arr-right")){
        	           		$(this).removeClass("arr-right");
        	           		$(this).addClass("arr-down");
        	           	}else{
        	           		$(this).removeClass("arr-down");
        	           		$(this).addClass("arr-right");
        	           	}
        	           });
	});
}
//展开下拉框 并点击空白处关闭
var selectConhideflag=true;
function bodyClick(){
	$("body").click(function(e){	
		if(selectConhideflag){	
		var aTxt =$("a[data-select2]");
		aTxt.each(function(){
			var selectCon=$(this).siblings("ul");
		       	selectCon.hide(); 
		});
		}else{
			selectConhideflag=true;
		}

		//日历插件
		if(/ul|li|div/i.test(e.target.tagName)){//点击页面的ul，li，div执行隐藏，要什么自己加！
			calendar.hide();
		}

		//隐藏所有字段
		if(/th|ul|div/i.test(e.target.tagName)){//点击页面的ul，li，div执行隐藏，要什么自己加！
			$(".mark-setbox").hide();
		}

		//隐藏所有字段
		if(/th|ul|div/i.test(e.target.tagName)){//点击页面的ul，li，div执行隐藏，要什么自己加！
			$("[data-pagesnumins]").hide();
		}
		
	});

}
function delHtmlTag(str){
		return str.replace(/<[^>]+>/g,"");//去掉所有的html标记
	}
function showSelectBox2(){
	var aTxt =$("a[data-select2]");
	aTxt.each(function(){
		var selectCon=$(this).siblings("ul");
		var selectConNext=$(this).parent("div").parent("li").siblings("li").children('.u-downselect').children("ul");
        	             //console.info(1212);
        	           	//console.info(this);
        	           $(this).click(function(){
        	           	selectConhideflag=false;
        	           	var ipt=$(this).children('input');
        	           	var isSpan = false;
        	           	if(ipt.length==0){
 			isSpan = true;
 			ipt=$(this).children('span');
        	           	}
        	           	selectCon.toggle();
        	           	selectConNext.hide();
        	           	selectCon.children("li").each(function(){
        	           		$(this).click(function(){
        	           			if(isSpan){
        	           				ipt.html($(this).html());
        	           			}else{
        	           				if($(this).data("selecttxt")=="main"){
        	           					var str1 =$(this).children("span.f_l").html();
						//console.info(delHtmlTag(str1));
        	           					ipt.val(delHtmlTag(str1));
					}else{
						ipt.val($(this).html());
					}
        	           				
        	           			}
        	           			selectCon.hide();
        	           			
        	           		});
        	           	});  
        	           	 	           	
        	           });
	});
}

$("[data-valnull]").each(function(){
	$(this).click(function() {
		$(this).parent("ul").siblings('a').children('input').focus();
		$(this).parent("ul").siblings('a').children('input').addClass('focus');
	});
});
//单选
$("[data-radio]").each(function(){
	$(this).click(function(){
		var obj=$(this).children("span");
		var siblingsObj=$(this).siblings("a").children("span");
		for(var i=0;i<siblingsObj.length;i++){
			if(siblingsObj.eq(i).hasClass("on")){
				siblingsObj.eq(i).removeClass("on");
				obj.addClass("on");
			}
		}
	});
});
//单选2
$("[data-radio2]").each(function(){
	$(this).click(function(){
		$(this).addClass("on");
		var siblingsObj=$(this).parent("li").siblings("li").children('[data-radio2]');
		for(var i=0;i<siblingsObj.length;i++){
			if(siblingsObj.eq(i).hasClass("on")){
				siblingsObj.eq(i).removeClass("on");
				$(this).addClass("on");
			}
		}
	});
});
//单选3
$("[data-radio3]").each(function(){
	$(this).click(function(){
		$(this).addClass("on");
		var siblingsObj=$(this).siblings("[data-radio3]");
		for(var i=0;i<siblingsObj.length;i++){
			if(siblingsObj.eq(i).hasClass("on")){
				siblingsObj.eq(i).removeClass("on");
				$(this).addClass("on");
			}
		}
	});
});
//勾选与全选
function selectOn(){
	var btnGou=$("[data-gou]");
	btnGou.each(function(){
		$(this).click(function(){
			if($(this).data("gou")=="all"){
				if($(this).hasClass("on")){
					$(this).removeClass("on");
					console.log($(this));
					$(this).closest("table").find("[data-gou]").each(function(){
						$(this).removeClass("on");
					});
				}else{
					$(this).addClass("on");
					$(this).closest("table").find("[data-gou]").each(function(){
						$(this).addClass("on");
					});
				}
			}else{
				if($(this).hasClass("on")){
					$(this).removeClass("on");
					$(this).closest("table").find("span[data-gou=all]").removeClass("on");
				}else{
					$(this).addClass("on");
					var count = 0;
					$(this).closest("table").find("[data-gou]").each(function(){
						if($(this).hasClass("on")){
							count++;	
						}
					});
					if(count+1 == $(this).closest("table").find("[data-gou]").length){
						$(this).closest("table").find("span[data-gou=all]").addClass("on");
					}
				}				
			}
		});
	});
}
//当表格中出现两种类型的勾选
$("[data-gou2]").each(function(){
	$(this).click(function(){
		if($(this).hasClass("on")){
			$(this).removeClass("on");
		}else{
			$(this).addClass("on");
		}
	});
});
 /*tab标题切换效果*/  
     function doClick(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=5;i++){ //这里5 需要你修改 你多少条分类 就是多少
		    id ="nav"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub"+i);
		    if(id != o.id){
			      j.className="";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
	  //window.location.reload();
    }  
     function doClick2(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=8;i++){ //这里5 需要你修改 你多少条分类 就是多少
		    id ="nav2"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub2"+i);
		    if(id != o.id){
		    		//console.log(id);
			      j.className="nav_link";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
    }
    function doClick3(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=3;i++){ //这里5 需要你修改 你多少条分类 就是多少
		    id ="nav3"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub3"+i);
		    if(id != o.id){
		    		//console.log(id);
			      j.className="nav_link";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
    }
    function doClick4(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=7;i++){ //这里5 需要你修改 你多少条分类 就是多少
		    id ="nav4"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub4"+i);
		    if(id != o.id){
		    		//console.log(id);
			      j.className="nav_link";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
    }
     function doClick5(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=6;i++){ //这里5 需要你修改 你多少条分类 就是多少
		    id ="nav5"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub5"+i);
		    if(id != o.id){
		    		//console.log(id);
			      j.className="nav_link";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
    }
    function doClick6(o){
	  o.className="nav_current";
	  var j;
	  var id;
	  var e;
	  for(var i=1;i<=3;i++){ //这里3 需要你修改 你多少条分类 就是多少
		    id ="nav6"+i;	  
		    j = document.getElementById(id);
		    e = document.getElementById("sub6"+i);
		    if(id != o.id){
		    		//console.log(id);
			      j.className="nav_link";
			      e.style.display = "none";
		    }else{
		   	e.style.display = "block";
		    }
	  }
    }
  /*end tab标题切换效果*/
//选择每页显示多少条列表		
  $("[data-pagesnum]").click(function(){
  	$(this).siblings("ul").toggle();	  
  	$(this).siblings("ul").children("li").each(function(){
  	  	$(this).click(function(){
  	  		$(this).parent("ul").hide();
  	  			if($(this).siblings('li').children("span").hasClass("on")){
  	  				$(this).siblings('li').children("span").removeClass("on");
  	  				$(this).children("span").addClass("on");
  	  			}
  	  		$(this).children("span").addClass('on');
  	  		$(this).parent("ul").siblings("[data-pagesnum]").children("em").html($(this).children("span").html());
  	  	});
  	  });
 });

//弹出输入框
$("[data-showIpt]").each(function(){
	$(this).click(function() {
		
	});
});

//获取date日历输入框赋值当天的日期
var today = new Date();
var dateInput=document.getElementsByName("date");
for(var i=0;i<dateInput.length;i++){
	dateInput[i].value = today.format(calendar.date2StringPattern);
}

//日历图片添加点击时间，调出日历
$(".icon-calendar").each(function(){
	$(this).click(function(){
		var input = $(this).siblings("input")[0];
		calendar.show(input);	
	});
});

//点击条目出现弹出层显示对应内容，以data-属性为查找器
function showMark(){
            var btnShowMark =$("a[data-showmarkbox]");
            var markBoxLi =$(".mark_info .ins[data-showmarkbox]");
            btnShowMark.each(function(){
            	           $(this).click(function(){
            	           	             console.log("1111");
		          	 var thisData =$(this).data("showmarkbox");
		          	 for(var i=0;i<markBoxLi.length;i++){
		          	 	$(markBoxLi[i]).hide();
		          	             var markBoxLiData =$(markBoxLi[i]).data("showmarkbox");
		          	             if(thisData==markBoxLiData){
                                                                $(markBoxLi[i]).data("showmarkbox",markBoxLiData).show();
                                                                $(markBoxLi[i]).data("showmarkbox",markBoxLiData).parents(".mark_info").show();
                                                   }
                                                   console.log("222");
                                                   
                                        }
		});
            });
}
//展开关闭弹出层
/*$("[data-showmarkbox]").each(function(){
	$(this).click(function(){
		$(".mark_info").show();
	});
});*/
function hideMark(){
	$("[data-closemarkbox]").each(function(){
	$(this).click(function(){
		console.log("111");
		$(".mark_info").css("display","none");
		});
	});
}


//删除
function deleteSelf(){
	$("[data-delete]").unbind('click').click(function(){
		//obj.remove();
		//$("[data-setbox]").hide();
		var btnRemove=$("[data-setbox]").find(".nav-down").find("li").children("a").children("i");
		btnRemove.show();
		btnRemove.each(function(){
			$(this).click(function(){
				$(this).parent("a").parent("li").remove();
			});
		});
	});
}

//复制
function copySelf(obj){
	$("[data-copy]").unbind('click').click(function(){
		var tdDom = $("<td data-showbtnsbox>"+obj.html()+"</td>");
		$(tdDom).click(function(){
			clickBtn($(this));
		});
		obj.after(tdDom);
		//$("[data-btnsbox]").hide();
		$("[data-setbox]").hide();
	});
}
//点击Btn
function clickBtn (o){	
	o.addClass("on");
	$("[data-setbox]").show();

	if($("[data-btnsbox]").is(":hidden")){
		$(this).removeClass("on");
	}
	if(o.siblings("[data-showbtnsbox]").hasClass("on")){
		o.siblings("[data-showbtnsbox]").removeClass("on");
	}
	var n=o.index();
	var sWidth=o.width()*n;
	$("[data-setbox]").css("left",sWidth+n+"px");
	showsetbox(o);
	getTxt(o);
	copySelf(o);
}
//点击文本框设置字段
function getTxt(obj){
	var txt=$("[data-setbox]").find(".nav-down").find("li").children("a");
	txt.each(function(){
		$(this).unbind('click').click(function(){
			obj.children("span").html($(this).html());
			//console.log(obj);
		});	
	});
}
//展开设置按钮，循环添加点击事件
$("[data-showbtnsbox]").each(function(){
	$(this).click(function() {
		clickBtn ($(this));
	});
});


$("[data-closebtnsbox]").each(function(){
	$(this).click(function(){
		$("[data-btnsbox]").hide();
		
	});
});
//展开关闭表格字段设置层
function showsetbox(obj){
	//清空
	$("[data-metaname]").val("");
	$("[data-order]").val("");
	$("[data-vipLevel]").val("选择会员级别");
	
	$("[data-showsetbox]").each(function(){
	$(this).unbind('click').click(function() {
		$("[data-setbox]").show();
		var name=$("[data-metaname]").val();
		obj.children("span").html(name);
		//console.log(obj);	
		$(".mark_info").hide();
		});
		var btnRemove=$("[data-setbox]").find(".nav-down").find("li").children("a").children("i");
	             btnRemove.hide();
		deleteSelf();
	});
}

$("[data-closesetbox]").each(function(){
	$(this).click(function(){
		$("[data-setbox]").hide();
		$("[data-showbtnsbox]").removeClass("on");
	});
});


//创建一个可编辑表格
var tableSetTd=$('<td data-showbtnsbox></td>');
var tableSetSpan=$('<span></span>').appendTo(tableSetTd);

//操作按钮控制
//启用 禁用
$("[data-setState]").each(function(){
	$(this).click(function(){
		var stateObj=$(this).parent("div").parent("td").siblings("td[data-state]").children('div').children('span');
		if($(this).html()=="禁用"){
			stateObj.html("已禁用");
			stateObj.removeClass("green_txt");
			stateObj.addClass("red_txt");
			$(this).html("启用");
		}else{
			stateObj.html("已启用");
			stateObj.removeClass("red_txt");
			stateObj.addClass("green_txt");
			$(this).html("禁用");
		}
		
	});
});
//删除一行表格内容
$("[data-delete]").each(function(){
	$(this).click(function(){
		var trPar=$(this).parent("div").parent("td").parent("tr");
		trPar.hide(200);
	});
});
//判断邮箱的字段从而控制修改按钮的浮动方向 xj2016-3-21
function controlMailwidth(){
	if($("[data-mailwidth]").width()>157){
		$("[data-mailwidth]").next().removeClass('f_r');
		$("[data-mailwidth]").next().addClass('f_l');
	}
}
//点击显示快递信息
$("[data-showkdinfo]").each(function(){
	$(this).click(function() {
		if($(this).siblings('[data-kdinfo]').is(':visible')){
			$(this).siblings('[data-kdinfo]').hide();
			$(this).removeClass("on");
		}else{
			$(this).siblings('[data-kdinfo]').show();
			$(this).addClass("on");
		}
		
	});
});
//点击显示站内信订阅管理表格详情
$("[data-btnshowdetail]").each(function(){
	$(this).click(function(){
		var detailBox=$(this).parent("div").parent('td').parent("tr").siblings('tr').children('[data-tableDetail]');
		console.log(111);
		if(detailBox.is(':visible')){
			detailBox.hide();
			$(this).removeClass("on");
		}else{
			detailBox.show();
			$(this).addClass("on");
		}
		
	});
});
//星级
$(".icon-stars").each(function(){
	$(this).click(function(){
		if($(this).hasClass("on")){
			$(this).removeClass('on');
		}else{
			$(this).addClass('on');
		}
	});
});
//删除附件
$("[data-deletAttach]").each(function(){
	$(this).click(function(){
		$(this).parent("li").remove();
	});
});

//var $,jQuery;
(function($){	
	//*************************************//
	//*************菜单左右切换插件*************//
	//************************************//	
	$.fn.oTabMenus = function (options) {
		//定义要用的参数
		var opts = {
			oTabMenuList: '',
			oMenuBtnL:'',
			oMenuBtnR:'',
			Distance:1,  //间隔
			greypreClass:'',
			greynextClass:''
		};
		var opt = $.extend(opts, options);
		return this.each(function () {
			var _obj = $(this),
			 	aLi = $(opt.oTabMenuList).find("li"),
			 	aMenus = $(opt.oTabMenuList).find("li a"),
				disX=0,
				l=0;			

			function reset() {
				var ulWidth;
				for (var i = 0; i < aLi.length; i++) {
					ulWidth += aLi.eq(i).width() + opt.Distance;
					//console.log(aLi.eq(i));
				}
				$(opt.oTabMenuList).css("width", ulWidth);
				
				if ($(opt.oTabMenuList).width() > _obj.width()) {
					$(opt.oMenuBtnR).addClass(opt.greynextClass);
				}
				disX = $(opt.oTabMenuList).width() - _obj.width();
				//console.log($(opt.oTabMenuList).width());
			}
			reset();
			function move(dis) {
				$(opt.oTabMenuList).animate({"left": dis}, 500);
			}
			$(opt.oMenuBtnR).click(function () {
				if (l >= -disX) {
					//l += -(aLi.width()+opt.Distance);
					l += -(_obj.width());
					move(l);			
				}
				if (l < 0) {
					$(opt.oMenuBtnL).addClass(opt.greypreClass);
					//oMenuBtnL.fadeIn();			
				}
				if (l < -disX) {
					$(opt.oMenuBtnR).removeClass(opt.greynextClass);
					//oMenuBtnR.fadeOut();
				}
			});
			$(opt.oMenuBtnL).click(function () {
				if (l < 0) {
					//l += aLi.width()+opt.Distance;
					l += _obj.width();
					move(l);			
				}
				if (l >= 0) {
					$(opt.oMenuBtnL).removeClass(opt.greypreClass);
					//oMenuBtnL.fadeOut();
				}
				if (l >= -disX) {
					$(opt.oMenuBtnR).addClass(opt.greynextClass);
					//oMenuBtnR.fadeIn();
				}
			});
		});
		return this;
	};
	
//all end
})(jQuery);


